/* eslint-disable react/prop-types */
import './scroll.scss'

export const CustomScroll = ({ children }) => {
	return <div className='custom__scroll-container'>{children}</div>
}

